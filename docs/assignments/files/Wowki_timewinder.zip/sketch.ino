#include <Adafruit_NeoPixel.h>

// ── Pins ────────────────────────────────────────────────
#define PIN_SW   4
#define PIN_A    5
#define PIN_B    6
#define PIN_LED  7
#define NUM_LEDS 12

Adafruit_NeoPixel ring(NUM_LEDS, PIN_LED, NEO_GRB + NEO_KHZ800);

// ── State machine ───────────────────────────────────────
// IDLE       → waiting for first button press
// COUNTING   → encoder active, counting CW turns
// RUNNING    → countdown active, LEDs dimming
// ALARMING   → timer done, ring flashing until button press
enum State { IDLE, COUNTING, RUNNING, ALARMING };
State state = IDLE;

// ── Encoder ─────────────────────────────────────────────
int lastA           = 0;
int count           = 0;      // CW turns accumulated
int pending         = 0;
unsigned long lastPulse = 0;
const unsigned long GAP = 1000;

// ── Button ──────────────────────────────────────────────
int lastSW              = HIGH;
unsigned long lastPress = 0;
const unsigned long DEBOUNCE = 200;

// ── LED ring ─────────────────────────────────────────────
int lit                 = 0;
unsigned long lastDim   = 0;
const unsigned long DIM_INTERVAL = 2000;

// ── Flash ───────────────────────────────────────────────
bool flashState         = false;
unsigned long lastFlash = 0;
const unsigned long FLASH_INTERVAL = 150;

// ── Helpers ─────────────────────────────────────────────
void showRing(int count) {
  ring.clear();
  for (int i = 0; i < count; i++) {
    ring.setPixelColor(i, ring.Color(0, 210, 160));
  }
  ring.show();
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_A,  INPUT_PULLUP);
  pinMode(PIN_B,  INPUT_PULLUP);
  pinMode(PIN_SW, INPUT_PULLUP);

  lastA  = digitalRead(PIN_A);
  lastSW = digitalRead(PIN_SW);

  ring.begin();
  ring.setBrightness(80);
  ring.clear();
  ring.show();

  Serial.println("IDLE — press button to start counting turns");
}

void loop() {

  // ── Button ──────────────────────────────────────────
  int currentSW = digitalRead(PIN_SW);

  if (currentSW == LOW && lastSW == HIGH) {
    if (millis() - lastPress >= DEBOUNCE) {
      lastPress = millis();

      if (state == IDLE) {
        // first press — activate encoder
        state  = COUNTING;
        count  = 0;
        pending = 0;
        Serial.println("COUNTING — rotate CW to set turns, press again to start");

      } else if (state == COUNTING) {
        // second press — lock in turn count, start countdown
        if (count == 0) {
          Serial.println("No turns counted — rotate CW first");
        } else {
          lit     = constrain(count, 1, NUM_LEDS);
          state   = RUNNING;
          lastDim = millis();
          showRing(lit);
          Serial.print("RUNNING — ");
          Serial.print(lit);
          Serial.println(" LEDs on, counting down");
        }

      } else if (state == RUNNING) {
        // press during countdown — cancel and reset
        state = IDLE;
        count = 0;
        ring.clear();
        ring.show();
        Serial.println("Cancelled — IDLE");

      } else if (state == ALARMING) {
        // press during alarm — clear and reset
        state      = IDLE;
        count      = 0;
        flashState = false;
        ring.clear();
        ring.show();
        Serial.println("Alarm cleared — IDLE");
      }
    }
  }
  lastSW = currentSW;

  // ── Encoder — only in COUNTING state ────────────────
  if (state == COUNTING) {
    int currentA = digitalRead(PIN_A);

    if (currentA != lastA) {
      int dir = (digitalRead(PIN_B) != currentA) ? 1 : -1;
      if (dir == 1) {
        // CW only — ignore CCW
        pending   = 1;
        lastPulse = millis();
      }
    }
    lastA = currentA;

    if (pending != 0 && millis() - lastPulse >= GAP) {
      count += pending;
      pending = 0;
      Serial.print("Turns: ");
      Serial.println(count);
    }
  }

  // ── Countdown — only in RUNNING state ───────────────
  if (state == RUNNING && millis() - lastDim >= DIM_INTERVAL) {
    lastDim = millis();
    lit--;

    if (lit > 0) {
      showRing(lit);
      Serial.print("LEDs remaining: ");
      Serial.println(lit);
    } else {
      state      = ALARMING;
      flashState = false;
      lastFlash  = millis();
      Serial.println("ALARMING — press button to stop");
    }
  }

  // ── Flash — only in ALARMING state ──────────────────
  if (state == ALARMING && millis() - lastFlash >= FLASH_INTERVAL) {
    lastFlash  = millis();
    flashState = !flashState;

    if (flashState) {
      for (int i = 0; i < NUM_LEDS; i++) {
        ring.setPixelColor(i, ring.Color(0, 210, 160));
      }
    } else {
      ring.clear();
    }
    ring.show();
  }
}