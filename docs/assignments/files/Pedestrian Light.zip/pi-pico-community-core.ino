#define RED 1
#define YELLOW 5
#define GREEN 9
#define BUTTON 28


void setup() {
  pinMode(RED, OUTPUT);
  pinMode(YELLOW, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BUTTON, INPUT_PULLUP);
}

void loop() {
  digitalWrite(GREEN, HIGH);
  while (digitalRead(BUTTON) == HIGH) {
  }
    digitalWrite(GREEN, LOW);
    digitalWrite(YELLOW, HIGH);
    delay(1000);
    digitalWrite(YELLOW, LOW);
    digitalWrite(RED, HIGH);
    delay(4000);

    digitalWrite(YELLOW, HIGH);
    delay(500);
    digitalWrite(YELLOW, LOW);
    digitalWrite(RED, LOW);
}
